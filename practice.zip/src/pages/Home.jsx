import React from 'react';
import HeroSection from "../components/HeroSection/HeroSection"
const Home = () => {
  return (
    <div >
      <HeroSection />
    </div>
  );
}

export default Home;
